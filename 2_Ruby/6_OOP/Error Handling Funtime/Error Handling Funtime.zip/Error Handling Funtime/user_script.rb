require_relative 'super_useful'

feed_me_a_fruit

sam = BestFriend.new('bob', 5, 'making samiches')

sam.talk_about_friendship
sam.do_friendstuff
sam.give_friendship_bracelet
